/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, serverTimestamp, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase using the provisioned configuration
const app = initializeApp(firebaseConfig);

// Initialize Firestore using the exact provisioned database ID
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Startup connection verification
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Firestore client is offline. Verify configuration and connectivity.");
    }
  }
}
testConnection();

export interface ConsultationBrief {
  name: string;
  company?: string;
  email: string;
  projectType: string;
  message: string;
}

export const saveConsultation = async (brief: ConsultationBrief): Promise<string> => {
  const path = 'consultations';
  try {
    const docRef = await addDoc(collection(db, path), {
      name: brief.name.trim(),
      company: (brief.company || '').trim(),
      email: brief.email.trim(),
      projectType: brief.projectType,
      message: (brief.message || '').trim(),
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
};

export interface ChatMessageSession {
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export const saveChatSessionMessage = async (sessionId: string, messages: ChatMessageSession[]): Promise<void> => {
  const path = 'chat_sessions';
  try {
    const sessionRef = collection(db, path);
    await addDoc(sessionRef, {
      sessionId,
      messages,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};
